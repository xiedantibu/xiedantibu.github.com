//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DocsOnline.rc
//
#define IDC_MYICON                      2
#define IDD_DOCSONLINE_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDD_SETTINGS                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_DOCSONLINE                  107
#define IDI_SMALL                       108
#define IDC_DOCSONLINE                  109
#define ID_STARTSTOP                    110
#define ID_CLEARLIST                    111
#define IDM_UPLOADREMOVE                112
#define ID_CONVERTDOCS                  113
#define IDM_UPLOADRETRY                 114
#define IDR_MAINFRAME                   128
#define IDR_APP_POPUP_MENU              129
#define IDB_MAINTB                      131
#define IDB_BITMAP1                     132
#define IDB_STATI                       132
#define IDC_USERNAME                    1000
#define IDC_PASSWORD                    1001
#define IDC_PREMIER                     1003
#define IDC_FOLDERS                     1004
#define IDC_ADDFOLDER                   1006
#define IDC_AUTOSTART                   1007
#define IDC_DELETEFOLDER                1008
#define IDC_RECREATESTRUCT              1012
#define IDC_RADIO3                      1013
#define IDC_ROOTUPLOAD                  1013
#define IDC_MIRRORFOLDERS               1014
#define ID_SETTINGS                     32771
#define ID_EXIT                         32772
#define ID_EXIT_EXIT                    32773
#define ID__SETTINGS                    32774
#define ID_UPLOADREMOVE                 32775
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
