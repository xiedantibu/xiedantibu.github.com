#pragma once

#define VER_MAJOR    1
#define VER_MINOR    3
#define VER_RELEASE  0
#define VER_BUILD    0  

#define MY_VER VER_MAJOR,VER_MINOR,VER_RELEASE,VER_BUILD
#define STR_VER "1.3.0.0"

