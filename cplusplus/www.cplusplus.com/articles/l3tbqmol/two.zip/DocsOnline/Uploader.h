#pragma once

class CUploader
{
public:
  CUploader(void);
  virtual ~CUploader(void);
};
