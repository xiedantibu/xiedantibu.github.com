#pragma once

#define HTTP_POST_VERB                      L"POST"
#define HTTP_CONTENT_LENGTH                 L"Content-Length"
#define HTTP_CONTENT_TYPE                   L"Content-Type"
#define HTTP_MIME_BINARY                    L"application/octet-stream"
#define HTTP_MIME_FORM_URL_ENCODED          L"application/x-www-form-urlencoded"
                                                
class CSmartHTTP
{
public:
  typedef enum { RES_SUCCESS, RES_ABORT, RES_EWININET, RES_EINPUTSTREAM, RES_EOUTPUTSTREAM } RESULT;
  CSmartHTTP();
  ~CSmartHTTP(void);
  BOOL Connect(LPCTSTR szServerName, INTERNET_PORT nServerPort = INTERNET_DEFAULT_HTTP_PORT);
  void Disconnect();
  BOOL Post(RESULT &res, DWORD &httpStatus, streambuf &reply, LPCTSTR engine, LPCTSTR header, 
    streambuf &content, __int64 contentLength, BOOL secure, HANDLE abortEvent = NULL);
  __int64 GetPostSent() { return m_postSent; }
  DWORD GetError() { return m_error; }

  static void AddHeader(wstring &header, LPCTSTR key, LPCTSTR value);
  static wstring GetMIMETypeOrBinary( const wstring extention );

private:
  static const map<wstring, wstring> m_ext2MIME;
  CRITICAL_SECTION m_cs;
  __int64 m_postSent;

  HINTERNET m_hInet;
  HINTERNET m_hConnection;
  DWORD m_error;
  HANDLE m_events[2];
  int m_eventsCount;

  BOOL Initialize();
  void Uninitialize();
  static void PrepareInetBuffer(INTERNET_BUFFERS *ib);
  void AsyncPrepare();
  BOOL AsyncEnd(RESULT &res);
  BOOL AsyncResult(RESULT &res, BOOL bAsyncResult);
  static void __stdcall InternetCallback(HINTERNET hInternet,
    DWORD dwContext,
    DWORD dwInternetStatus,
    LPVOID lpvStatusInformation,
    DWORD dwStatusInformationLength);
  BOOL SendRequest(RESULT &res, HINTERNET hRequestSession, LPCTSTR header, streambuf &content, __int64 contentLength);
  BOOL ReadReply(RESULT &res, streambuf &reply, HINTERNET hRequestSession);
  BOOL CheckResult(BOOL syncResult);
  BOOL IsAbort();
};
