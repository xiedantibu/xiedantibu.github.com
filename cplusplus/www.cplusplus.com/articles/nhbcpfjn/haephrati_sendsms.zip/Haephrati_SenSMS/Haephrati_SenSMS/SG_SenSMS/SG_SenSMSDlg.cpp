/*@ SendSMS - Send SMS from a C++ desktop applicaiton                       */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* Written and Designed by Michael Haephrati                                */
/* COPYRIGHT �2008 by Michael Haephrati    haephrati@gmail.com              */
/* http://michaelhaephrati.com												*/
/* All rights reserved.                                                     */
/* -------------------------------------------------------------------------*/

#include "stdafx.h"
#include "SG_SenSMS.h"
#include "resource.h"
#include "SG_SenSMSDlg.h"
#include "afxdialogex.h"
#include "WinHTTPClient.h"

//#include "PDU.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//v 2018057505

#include <shlwapi.h> 
#include <ole2.h>
#pragma comment (lib, "shlwapi.lib")

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CSG_SenSMSDlg dialog




CSG_SenSMSDlg::CSG_SenSMSDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSG_SenSMSDlg::IDD, pParent)
	, m_From(_T(""))
	, m_CountryCode(_T("972"))
	, m_To(_T(""))
	, m_Message(_T(""))
	, m_Status(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSG_SenSMSDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_From);
	DDX_Text(pDX, IDC_EDIT3, m_CountryCode);
	DDX_Text(pDX, IDC_EDIT2, m_To);
	DDX_Text(pDX, IDC_EDIT4, m_Message);
	DDX_Text(pDX, IDC_STATUS, m_Status);
}

BEGIN_MESSAGE_MAP(CSG_SenSMSDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CSG_SenSMSDlg::OnBnClickedOk)
	ON_NOTIFY(NM_CLICK, IDC_SYSLINK1, &CSG_SenSMSDlg::OnNMClickSyslink1)
	ON_NOTIFY(NM_CLICK, IDC_SYSLINK2, &CSG_SenSMSDlg::OnNMClickSyslink2)
	ON_BN_CLICKED(IDC_BUTTON1, &CSG_SenSMSDlg::OnBnClickedButton1)
	ON_WM_CREATE()
	ON_STN_CLICKED(IDC_STATUS, &CSG_SenSMSDlg::OnStnClickedStatus)
END_MESSAGE_MAP()


// CSG_SenSMSDlg message handlers

BOOL CSG_SenSMSDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.
	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon



	// TODO: Add extra initialization here
	wchar_t result[80];
	GetProfileString(L"SendSMS",L"From",L"SendSMS",result,80);
	m_From=result;
	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSG_SenSMSDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSG_SenSMSDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		 CPaintDC dc(this); // device context for painting
        dc.SetBkColor(RGB(34, 255, 0));
        dc.SetTextColor(RGB(215, 0, 0));
		
        //dc.TextOut (130, 90, L"Hello");

		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSG_SenSMSDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CSG_SenSMSDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_To.Left(1)==L"0") 
	{
		m_To=m_To.Mid(1);
		
	}
	UpdateData(FALSE);
	WriteProfileString(L"SendSMS",L"From",m_From.GetBuffer());
	SendSms(m_From,m_CountryCode,m_To,m_Message,&m_Status);
	UpdateData(FALSE);
	//CDialogEx::OnOK();
}
BOOL SendSms(CString From, CString CountryCode, CString To,CString Message,CString *Status)
	// From - the ID or number you are sending from. This is what will appear at the recipient's cellphone. 
	// CountyCode - the code of the country you are sending the SMS to (for example: 44 is for the UK
	// To - is the number you are texting to, which should not contain any leading zeros, spaces, commas, etc.
	// Message - is the message you are sending, which can be any multi lingual text
	// The status returned would be either a confirmation number along with the text "OK", which means that the message
	// was delivered, or an error code. 
{
	BOOL result=FALSE;
	wstring user=L"PLACE_YOUR_USERNAME_HERE",pass=L"PLACE_YOUR_PASSWORD_HERE",request=L"";
	// 
	request=L"http://sms1.cardboardfish.com:9001/HTTPSMS?S=H&UN=";
	request+=user;	// user name
	request+=L"&P=";
	request+=pass;	// password
	request+=L"&DA="; // 
	request+=(wstring)(CountryCode+To); // country code
	request+=L"&SA="; // 
	request+=(wstring)From; // From (sender ID)
	request+=L"&M=";
	CString EncodedMessage; // Message
	
	CString ccc;
	EncodedMessage=ConvertHex(Message)+ConvertHex( L" Send SMS By Michael Haephrait http://�����������.com");
	
	request+=(wstring)EncodedMessage; // place here the message to send
	request+=L"&DC=4";
	WinHttpClient client(request);
		
	client.SendHttpRequest(L"GET",true);
    // Get the response

    wstring httpResponseHeader = client.GetResponseHeader();
    wstring httpResponseContent = client.GetResponseContent();
	*Status=httpResponseContent.c_str();
	return result;
}
CString ConvertHex(CString Text)
{
	CString result;
	result="";
	for (int i=0;i<Text.GetLength();i++)
	{
		int n = Text[i];  
        CString csTemp;  
		csTemp.Format( L"%.4X", n);
			
		result+=csTemp;
	}
	return result;
}

void CSG_SenSMSDlg::OnNMClickSyslink1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	ShellExecute(NULL, L"OPEN", L"mailto:vworker@gmail.com", NULL, NULL, SW_SHOWNORMAL);
	*pResult = 0;
}


void CSG_SenSMSDlg::OnNMClickSyslink2(NMHDR *pNMHDR, LRESULT *pResult)
{
	ShellExecute(NULL, L"OPEN", L"http://vworker.com", NULL, NULL, SW_SHOWNORMAL);
	
	// TODO: Add your control notification handler code here
	*pResult = 0;
}


void CSG_SenSMSDlg::OnBnClickedButton1()
{

}


int CSG_SenSMSDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here

	return 0;
}


void CSG_SenSMSDlg::OnStnClickedStatus()
{
	// TODO: Add your control notification handler code here
}
