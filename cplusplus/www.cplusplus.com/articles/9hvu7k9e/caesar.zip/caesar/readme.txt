* Compiler requirements

Your C++ compiler must support the C++11 standard.
Rule of thumb: if it's from before 2011, don't bother.


* Program usage

The resulting executable has no graphical user interface (GUI).
You are expected to run it from the command line, or the shell.


* Input files

The program is meant to be used on ANSI text files.
It will corrupt non-text files, and it may corrupt Unicode text files.
The "corruption" should be reversible, however.
