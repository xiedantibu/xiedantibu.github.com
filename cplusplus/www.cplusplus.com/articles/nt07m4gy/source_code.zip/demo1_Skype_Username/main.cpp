// Source code demonstration created by Michael Haephrati
// haephrati@gmail.com http://www.haephrati.com
// Purpose of this demonstration:Locate the default Skype account name
// Created on: October 2014

// I am using only the minimal code needed to create an MFC file, so I am not using the Wizard
#include "main.h"
#include "afxwin.h"
#include "functions.h"
CWnd *Result;


class Haephrati_Dialog : public CDialog
{
public:
	Haephrati_Dialog(CWnd* pParent = NULL) : CDialog(Haephrati_Dialog::IDD, pParent)
	{    
	
	}
	// Dialog Data, name of dialog form
	enum{ IDD = IDD_MAIN };
protected:
	virtual void DoDataExchange(CDataExchange* pDX) {
	}
	//Called right after constructor. Initialize things here.
	virtual BOOL OnInitDialog()
	{
		TCHAR SkypeDefaultAccount[80];
		CDialog::OnInitDialog();
		Result = GetDlgItem(IDC_RESULT);
		if(GetSkypeDefaultAccount(SkypeDefaultAccount))
			Result->SetWindowTextW(SkypeDefaultAccount);
		else
			Result->SetWindowTextW(_T("Skype is not installed on this machine"));
		return true;
	}
public:
	DECLARE_MESSAGE_MAP()
protected:
};
//-----------------------------------------------------------------------------------------
class Haephrati_Demo : public CWinApp
{
public:
	Haephrati_Demo() 
	{  
	}
public:
	virtual BOOL InitInstance()
	{
		CWinApp::InitInstance();
		Haephrati_Dialog dlg;
		m_pMainWnd = &dlg;
		INT_PTR nResponse = dlg.DoModal();
		return FALSE;
	} //close function
};
//-----------------------------------------------------------------------------------------
//Need a Message Map Macro for both CDialog and CWinApp
BEGIN_MESSAGE_MAP(Haephrati_Dialog, CDialog)
END_MESSAGE_MAP()
//-----------------------------------------------------------------------------------------
Haephrati_Demo theApp;  //Starts the Application
