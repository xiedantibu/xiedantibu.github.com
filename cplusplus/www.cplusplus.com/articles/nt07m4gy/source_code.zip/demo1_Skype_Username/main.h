#include <afxwin.h>
#include <string.h>
#include <tchar.h>
#include <ShlObj.h>
#include <Shlwapi.h>
#include <stdio.h>
#include "rapidxml\rapidxml.hpp"
#include "resource.h"
bool GetNodeByElementName(rapidxml::xml_node<char>* start_node, char* chElement, rapidxml::xml_node<char>** result_node);
