// I use functions.h for all program's functionality
bool GetSkypeDefaultAccount(TCHAR *result);
