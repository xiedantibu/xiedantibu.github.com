var searchData=
[
  ['initials',['initials',['../class_encoder_dictionary.html#aab5d1599dc520ebde557907344a6ab68',1,'EncoderDictionary']]],
  ['is',['is',['../class_code_reader.html#a9bbe663f646dec31f5e46ffa84d9cf26',1,'CodeReader']]]
];
