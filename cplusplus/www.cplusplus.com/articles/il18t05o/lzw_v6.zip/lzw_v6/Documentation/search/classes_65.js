var searchData=
[
  ['encoderdictionary',['EncoderDictionary',['../class_encoder_dictionary.html',1,'']]]
];
