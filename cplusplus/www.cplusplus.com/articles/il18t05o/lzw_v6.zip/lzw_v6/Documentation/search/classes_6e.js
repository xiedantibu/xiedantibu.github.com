var searchData=
[
  ['node',['Node',['../struct_encoder_dictionary_1_1_node.html',1,'EncoderDictionary']]]
];
