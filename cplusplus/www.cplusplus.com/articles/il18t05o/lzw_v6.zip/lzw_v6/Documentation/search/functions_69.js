var searchData=
[
  ['increase_5fbits',['increase_bits',['../class_code_writer.html#aa12e5406c1ad43a4b66213486e232cad',1,'CodeWriter::increase_bits()'],['../class_code_reader.html#a0874297fc3da77fd1642dcdba2710cd4',1,'CodeReader::increase_bits()']]]
];
