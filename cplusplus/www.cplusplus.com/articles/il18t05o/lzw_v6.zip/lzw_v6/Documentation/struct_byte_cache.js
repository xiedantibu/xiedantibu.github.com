var struct_byte_cache =
[
    [ "ByteCache", "struct_byte_cache.html#a42fb6b7c34d87c301a398b1337e4485c", null ],
    [ "data", "struct_byte_cache.html#a1f8abcf1de6933566d607b5d479052df", null ],
    [ "used", "struct_byte_cache.html#a06ae6d940c6cab67efd1b5b9b6015f82", null ]
];