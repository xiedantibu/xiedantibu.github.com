var struct_encoder_dictionary_1_1_node =
[
    [ "Node", "struct_encoder_dictionary_1_1_node.html#acc89c9cdddc27bfc1257a38fdfb0a51d", null ],
    [ "c", "struct_encoder_dictionary_1_1_node.html#a4c65c5966fb2e44164767e354818dea6", null ],
    [ "first", "struct_encoder_dictionary_1_1_node.html#a403847ab54114481cff9a891d77c02a3", null ],
    [ "left", "struct_encoder_dictionary_1_1_node.html#a7ef06c335544785e96284b4ecc006a85", null ],
    [ "right", "struct_encoder_dictionary_1_1_node.html#ae15668e10208daadd596b6ccb163e155", null ]
];