var annotated =
[
    [ "ByteCache", "struct_byte_cache.html", "struct_byte_cache" ],
    [ "CodeReader", "class_code_reader.html", "class_code_reader" ],
    [ "CodeWriter", "class_code_writer.html", "class_code_writer" ],
    [ "EncoderDictionary", "class_encoder_dictionary.html", "class_encoder_dictionary" ]
];