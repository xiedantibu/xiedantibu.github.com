var class_f_s_b_allocator___elem_allocator =
[
    [ "BlocksVector", "struct_f_s_b_allocator___elem_allocator_1_1_blocks_vector.html", "struct_f_s_b_allocator___elem_allocator_1_1_blocks_vector" ],
    [ "MemBlock", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html", "class_f_s_b_allocator___elem_allocator_1_1_mem_block" ],
    [ "Data_t", "class_f_s_b_allocator___elem_allocator.html#aa47c699d1ed9d449af011dfa2b2d7d2f", null ],
    [ "allocate", "class_f_s_b_allocator___elem_allocator.html#a967442e377040609cc4f259c62f7bd02", null ],
    [ "deallocate", "class_f_s_b_allocator___elem_allocator.html#a23fc18ff33eff10baed7555f2ae4335e", null ],
    [ "BlockElements", "class_f_s_b_allocator___elem_allocator.html#a163ff22a30bb3f6239020eed6de77983", null ],
    [ "BlockSize", "class_f_s_b_allocator___elem_allocator.html#a0a3c76e0b590b912f94bb6ba18cb2fb0", null ],
    [ "blocksVector", "class_f_s_b_allocator___elem_allocator.html#a11a81742ce8802a05ccbc8cba40cb850", null ],
    [ "blocksWithFree", "class_f_s_b_allocator___elem_allocator.html#a3af9a4664cb588caa86c541fa8c566f1", null ],
    [ "DSize", "class_f_s_b_allocator___elem_allocator.html#a2d05aecd19eb984aeeb1e6eb525f0c32", null ],
    [ "ElemSizeInDSize", "class_f_s_b_allocator___elem_allocator.html#af05ec7bf3cbbd076b973dce6af5d320b", null ],
    [ "UnitSizeInDSize", "class_f_s_b_allocator___elem_allocator.html#a7f82b980e3dd56017855428513779054", null ]
];