var class_f_s_b_allocator2___elem_allocator =
[
    [ "Blocks", "struct_f_s_b_allocator2___elem_allocator_1_1_blocks.html", "struct_f_s_b_allocator2___elem_allocator_1_1_blocks" ],
    [ "allocate", "class_f_s_b_allocator2___elem_allocator.html#a8a8532c7b2a1007eda136537b4d82812", null ],
    [ "cleanSweep", "class_f_s_b_allocator2___elem_allocator.html#a4c6c7e7dca1ea835f3e8f596f4342d2a", null ],
    [ "deallocate", "class_f_s_b_allocator2___elem_allocator.html#ab5380e928263ffcc0aa2ca6a27f12111", null ],
    [ "freeAll", "class_f_s_b_allocator2___elem_allocator.html#a8548909a39e841aac906a3f176f2aad7", null ],
    [ "allocatedElementsAmount", "class_f_s_b_allocator2___elem_allocator.html#a485f8d12c4ce9d33e605a4370cb7d4d5", null ],
    [ "BlockElements", "class_f_s_b_allocator2___elem_allocator.html#a36cbb9a5db6f75e0f958e3ed684b8e59", null ],
    [ "blocks", "class_f_s_b_allocator2___elem_allocator.html#a95aa14130eacea84eb46c551e7fc8612", null ],
    [ "BlockSize", "class_f_s_b_allocator2___elem_allocator.html#a317501bac498adca55a3a22769665f8f", null ],
    [ "DSize", "class_f_s_b_allocator2___elem_allocator.html#a0b0505018163dbc0f79e74267a574616", null ],
    [ "ElemSizeInDSize", "class_f_s_b_allocator2___elem_allocator.html#a9f6baf99c36b3c697bfd82eb0786167b", null ],
    [ "freeList", "class_f_s_b_allocator2___elem_allocator.html#a96b4b35c54d070fbf6008070f9dd6d27", null ],
    [ "headIndex", "class_f_s_b_allocator2___elem_allocator.html#aa42ce3f9ab7eb7c74cfa7c222cf96f35", null ]
];