var class_f_s_b_allocator___elem_allocator_1_1_mem_block =
[
    [ "MemBlock", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a876bd346c7a291e4648f145f5e1ad8b2", null ],
    [ "allocate", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#aaf2f2163cb8e08ee4d27663e4a58e2bb", null ],
    [ "clear", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a2516996bb12aa7db4dcd082c22af4fd7", null ],
    [ "deallocate", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#ad964ef508c310e86df2befab9b542db9", null ],
    [ "isFull", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a84762d17932b702ea84269bab8f59a2e", null ],
    [ "allocatedElementsAmount", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a3f2270cff040fd778f2197f85fb993d0", null ],
    [ "block", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#aab0e65d0c48ab78b4ff0ab28b86d3f03", null ],
    [ "endIndex", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a278d360be64633db26e600e86e43f8df", null ],
    [ "firstFreeUnitIndex", "class_f_s_b_allocator___elem_allocator_1_1_mem_block.html#a0aae9a58aff1e586996bcb6655a9b80b", null ]
];